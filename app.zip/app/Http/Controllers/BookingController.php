<?php

namespace App\Http\Controllers;

use App\Booking;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Http;

class BookingController extends Controller
{

    public function index(Request $request)
    {
        $bookings = Booking::with("destination")->latest();
        if ($destination = $request->destination_id) {
            $bookings = $bookings->where("destination_id", $destination);
        }
        return $bookings->get();
    }

    private function sendSMS($phone, $sms)
    {

        $headers = [
            "Content-Type" => "application/json",
            "cmd" => "SEND_SMS",
            "domain" => env("SMS_DOMAIN")
        ];
        $response = Http::withHeaders($headers)->post(env("SMS_URL"), [
            "src" => "BOOKING",
            "dest" => $phone,
            "message" => $sms,
            "wait" => 0,
            "contractId" => env("SMS_CONTRACT_ID")
        ]);
        return json_decode($response->body())->code == 100;

    }

    public function store(Request $request)
    {
        $request->validate([
            "amount" => "required",
            "names" => "required",
            "phone_number" => "required|regex:/(07)[0-9]{8}/|max:10",
            "destination_id" => "required",
            "departure_time" => "required",
        ]);
        $bookings = Booking::where("destination_id", $request["destination_id"])->whereDate("created_at", now()->toDateString())->count();
        if ($bookings >= 24)
            return response()->json(["message" => "All places are taken!"]);

        $transaction_id = substr(now()->year, -2) . "HOR" . random_int(10000, 99999);
        $request["transaction_id"] = $transaction_id;
        Booking::create($request->only("amount", "names", "phone_number", "destination_id", "transaction_id", "departure_time"));
        return $this->pay($transaction_id, $request->amount, $request->names, $request->phone_number, "Travel payment")["data"]["link"];
    }

    private function pay($tx_ref, $amount, $names, $phoneNumber, $title)
    {
        $URL = "https://api.flutterwave.com/v3/payments";
        $SECRET_KEY = "FLWSECK-e3f66fbfcef1eabe29dd14890bbbd4f7-X";
        $response = Http::withToken($SECRET_KEY)->post($URL,
            [
                "tx_ref" => $tx_ref,
                "amount" => $amount,
                "currency" => "RWF",
                "redirect_url" => env("APP_URL") . "profile",
                "payment_options" => "card",
                "customer" => [
                    "phonenumber" => $phoneNumber,
                    "name" => $names,
                    "email" => "alainmucyo3@gmail.com"
                ],
                "customizations" => [
                    "title" => "Horizon",
                    "description" => "Payment for $title",
                ]
            ]
        );
        return json_decode($response, true);
    }

    public function paymentResponse(Request $request)
    {
        return $request["test"];
        /*  if (
              ($request["event"] != "charge.completed") ||
              $request["data"]["processor_response"] != "Approved" ||
              $request["data"]["status"] != "successful"
          ) {
              return response(["message" => "Failed"], Response::HTTP_BAD_REQUEST);
          }*/
        $booking = Booking::where("transaction_id", $request["data"]["tx_ref"])->first();
        $booking->update(["payed" => true, "payment_mode" => $request["data"]["payment_type"]]);
        $this->sendSMS("25" . $booking->phone_number,
            "Thank you for your payment. use this code to get your booked place: " . $booking->transaction_id);
        return response(["message" => "Ok"]);
    }

    public function validateBooking($transactionId)
    {
        $booking = Booking::where("transaction_id", $transactionId)->where("payed", true);
        if (!$booking)
            return response(["message" => "Booking not found"], 404);

        if ($booking->scanned)
            return response(["message" => "Booking already validated"], 402);

        $booking->update(["scanned" => true]);
        return response(["message" => "Scanned successfully"]);

    }
}
