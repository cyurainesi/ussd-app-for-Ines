<?php

namespace App\Http\Ussd\States;

use Sparors\Ussd\State;

class GetRecipientNumber extends State
{
    protected function beforeRendering(): void
    {
        $this->menu->text('Welcome to menu 1')
            ->lineBreak(2)
            ->text('Powered by Alain');
    }

    protected function afterRendering(string $argument): void
    {
        //
    }
}
