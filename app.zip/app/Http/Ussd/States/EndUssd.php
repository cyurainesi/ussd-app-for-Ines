<?php

namespace App\Http\Ussd\States;

use Sparors\Ussd\State;

class EndUssd extends State
{
    protected function beforeRendering(): void
    {
        $this->menu->text("Turaboherereza SMS mukoresha mwishyura");
    }

    protected function afterRendering(string $argument): void
    {
        //
    }
}
