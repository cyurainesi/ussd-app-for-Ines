<?php

namespace App\Http\Ussd\States;

use Sparors\Ussd\State;

class MaintenanceMode extends State
{
    protected function beforeRendering(): void
    {
        $this->menu->text('Welcome To Menu 2 or 5');
    }

    protected function afterRendering(string $argument): void
    {
        //
    }
}
