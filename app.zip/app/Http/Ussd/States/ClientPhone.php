<?php

namespace App\Http\Ussd\States;

use Sparors\Ussd\State;

class ClientPhone extends State
{
    protected function beforeRendering(): void
    {
        $this->menu->text("Shyiramo numore ya telephone");
    }

    protected function afterRendering(string $argument): void
    {
        $this->decision
            ->any(EndUssd::class);
    }
}
