<?php

namespace App\Http\Ussd\States;

use Sparors\Ussd\State;

class ClientNames extends State
{
    protected function beforeRendering(): void
    {
        $this->menu->text('Shyiramo amazina yawe');
    }

    protected function afterRendering(string $argument): void
    {
        $this->decision
            ->any(DepartureTime::class);
    }
}
