<?php

namespace App\Http\Ussd\States;

use Sparors\Ussd\State;

class Welcome extends State
{
    protected function beforeRendering(): void
    {
        $this->menu->text('Murakaza neza kuri Horizon.')
            ->lineBreak(2)
            ->line('Muhitemo urugendo')
            ->listing([
                'Kigali to huye',
                'Kigali to Rusizi',
            ]);
    }


    protected function afterRendering(string $argument): void
    {
        $this->decision
            ->any(ClientNames::class);
    }
}
